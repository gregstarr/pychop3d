from gmsh_interop.runner import *

from warnings import warn
warn("meshpy.gmsh is deprecated. Use gmsh_interop.runner instead.", DeprecationWarning)
