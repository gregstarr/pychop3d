from gmsh_interop.reader import *

from warnings import warn
warn("meshpy.gmsh_reader is deprecated. Use gmsh_interop.reader instead.", DeprecationWarning)
